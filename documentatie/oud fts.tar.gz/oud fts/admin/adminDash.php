<?php
    
    session_start();
    require_once '../functies.php'; //Include de functies.
    require_once 'headerUp.php'; // Zet de header bovenaan deze pagina.
?>


<html>
    <body>
    <header>
        <title> </title>
    </header>

    </body>
</html>    
