# FTS- Flex Ticket System
Ticketsystem made for pure educational use.

